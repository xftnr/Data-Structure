
/*  Student information for assignment:
 *
  *  On my honor, <PENGDI XIA>, this programming assignment is my own work
 *  and I have not provided this code to any other student.
 *
 *  UTEID:px353
 *  email address:xiapengdi@yahoo.com
 *  Unique section number:Gilbert Maldonado
 *  Number of slip days I am using:0
 */

/*
 * Question. The assignment presents three ways to rank teams using graphs.
 * The results, especially for the last two methods are reasonable.
 * However if all results from all college football teams are included
 * some unexpected results occur.
 *
 * Suggest another way of method of ranking teams using the results
 * from the graph. Thoroughly explain your method. The method can build
 * on one of the three existing algorithms.
 **************************************************************
 *
 *Answer:
 *since the team practice and change by the time. I would like to add a new element time.
 *We could make the time as the multiple of the tank. 
 *The more recent game would has more multiple. By choosing the algorithms. 
 *I would choose the dijkstra`s algorithm. Because more recent game would have shorter path.
 *I don`t want to use the unweighted method because it is inaccurate for calculation. 
 *since I already decide to choose time as my new ruler, the the weighted method will be
 *the best method explain my idea.
 */

public class GraphAndRankTester {

    public static void main(String[] args)  {
        testGraph();
        testUnconnectedGraph();

        String actual = "2014ap_poll.txt";
        String gameResults = "div12014.txt";

        FootballRanker ranker = new FootballRanker(gameResults, actual);

        ranker.doUnweighted(true);
        ranker.doWeighted(true);
        ranker.doWeightedAndWinPercentAdjusted(true);

        System.out.println();
        doRankTests(ranker);

        System.out.println();

    }

    //test for other files
    private static void doRankTests(FootballRanker ranker) {
        System.out.println("\nTESTS ON FOOTBALL TEAM GRAPH WITH FootBallRanker CLASS: \n");
        double actualError = ranker.doUnweighted(false);
        if(actualError == 10.1)
            System.out.println("Passed unweighted test");
        else
            System.out.println("FAILED UNWEIGHTED ROOT MEAN SQUARE ERROR TEST. Expected 10.1, actual: " + actualError);

        actualError = ranker.doWeighted(false);
        if(actualError == 8.5)
            System.out.println("Passed weigthed test");
        else
            System.out.println("FAILED WEIGHTED ROOT MEAN SQUARE ERROR TEST. Expected 8.5, actual: " + actualError);


        actualError = ranker.doWeightedAndWinPercentAdjusted(false);
        if(actualError == 4.2)
            System.out.println("Passed unweighted win percent test");
        else
            System.out.println("FAILED WEIGHTED  AND WIN PERCENT ROOT MEAN SQUARE ERROR TEST. Expected 4.2, actual: " + actualError);
    }

    //my test 1, for the integer weighted
    private static void testGraph() {
    	System.out.println("PERFORMING TESTS ON SIMPLE GRAPHS\n");
    	System.out.println("PERFORMING TEST ON GRAPH 1 - INTEGER WEIGHTS");
        String [][] edges =
               {{"A", "D", "1"},
                {"D", "C", "2"},
                {"C", "B", "3"},
                {"B", "D", "4"},
                {"D", "F", "2"},
                {"F", "E", "1"},
                {"A", "C", "7"},
                {"A", "B", "10"},
                {"D", "E", "9"}};

        Graph g = new Graph();
        for(String[] edge : edges) {
            g.addEdge(edge[0], edge[1], Integer.parseInt(edge[2]));
            g.addEdge(edge[1], edge[0], Integer.parseInt(edge[2]));
        }

        g.dijkstra("A");
        String actualPath = g.findPath("E").toString();
        String expected = "[A, D, F, E]";
        if(actualPath.equals(expected))
            System.out.println("Passed dijkstra path test.");
        else
            System.out.println("Failed dijkstra path test. Expected: " + expected + " actual " + actualPath);

        // find all paths using unweighted edges
        g.findAllPaths(false);
        int actualDiameter = g.getDiameter();
        if(actualDiameter == 2)
            System.out.println("Passed diameter test with weighted == false.");
        else
            System.out.println("Failed diameter test with weighted == false. Expected 2 got " + actualDiameter);

        double costOfLongestShortestPath = g.costOfLongestShortestPath();
        if(costOfLongestShortestPath == 2.0)
            System.out.println("Passed cost of longest shortest path test with weighted == false.");
        else
            System.out.println("Failed cost of longest shortest path test with weighted == false. Expected 2.0 got " + actualDiameter);

        System.out.println();

        String[] expectedPaths = {  "Name: D                    cost per path: 1.0000, num paths: 5",
                                    "Name: A                    cost per path: 1.4000, num paths: 5",
                                    "Name: B                    cost per path: 1.4000, num paths: 5",
                                    "Name: C                    cost per path: 1.4000, num paths: 5",
                                    "Name: E                    cost per path: 1.6000, num paths: 5",
                                    "Name: F                    cost per path: 1.6000, num paths: 5"};

        testAllPathsInfo(g, expectedPaths);

        // find all paths using weighted edges
        g.findAllPaths(true);
        actualDiameter = g.getDiameter();
        if(actualDiameter == 3)
            System.out.println("Passed diameter test with weighted == true.");
        else
            System.out.println("Failed diameter test with weighted == true. Expected 3 got " + actualDiameter);

        costOfLongestShortestPath = g.costOfLongestShortestPath();
        if(costOfLongestShortestPath == 7.0)
            System.out.println("Passed cost of longest shortest path test with weighted = true");
        else
            System.out.println("Failed cost of longest shortest path test with weighted = true. Expected 7.0 got " + actualDiameter);


        expectedPaths = new String[] {  "Name: D                    cost per path: 2.4000, num paths: 5",
                                        "Name: A                    cost per path: 3.2000, num paths: 5",
                                        "Name: F                    cost per path: 3.2000, num paths: 5",
                                        "Name: C                    cost per path: 3.4000, num paths: 5",
                                        "Name: E                    cost per path: 4.0000, num paths: 5",
                                        "Name: B                    cost per path: 5.0000, num paths: 5"};
        testAllPathsInfo(g, expectedPaths);
        secondGraphTest();
    }

    //my test 2 for the unweighted
    private static void secondGraphTest() {
        System.out.println("PERFORMING TEST ON GRAPH 2 - NON INTEGER WEIGHTS");

        String[][] edges = {{"E", "G", "9.6"},
                        {"D", "F", "4.0"},
                        {"E", "B", "8.0"},
                        {"F", "A", "6.0"},
                        {"F", "C", "4.0"},
                        {"C", "E", "6.9"},
                        {"D", "G", "8.0"},
                        {"E", "A", "5.7"},
                        {"C", "A", "0.4"},
                        {"D", "A", "6.1"},
                        {"D", "B", "7.9"},
                        {"C", "G", "5.4"},
                        {"A", "G", "7.1"},
                        {"E", "F", "4.4"}};

        Graph g = new Graph();
        for(String[] edge : edges) {
            g.addEdge(edge[0], edge[1], Double.parseDouble(edge[2]));
            g.addEdge(edge[1], edge[0], Double.parseDouble(edge[2]) * 2);
        }

        // find all paths using weighted edges
        g.findAllPaths(true);

        String[] expectedPaths = new String[] { "Name: D                    cost per path: 7.6167, num paths: 6",
                        "Name: E                    cost per path: 7.7667, num paths: 6",
                        "Name: C                    cost per path: 8.0333, num paths: 6",
                        "Name: F                    cost per path: 8.4167, num paths: 6",
                        "Name: A                    cost per path: 8.5667, num paths: 6",
                        "Name: G                    cost per path: 16.4000, num paths: 6",
                        "Name: B                    cost per path: 19.9333, num paths: 6"};

        testAllPathsInfo(g, expectedPaths);
    }

    // Test an unconnected graph.(did not change this)
    private static void testUnconnectedGraph() {
        String [][] edges =
        {{"A", "B", "13"},
         {"A", "C", "10"},
         {"A", "D", "2"},
         {"B", "E", "5"},
         {"C", "B", "1"},
         {"D", "C", "5"},
         {"E", "G", "1"},
         {"E", "F", "4"},
         {"F", "C", "3"},
         {"F", "E", "2"},
         {"G", "F", "2"},
         {"H", "I", "10"},
         {"H", "J", "5"},
         {"H", "K", "22"},
         {"I", "K", "3"},
         {"I", "J", "1"},
         {"J", "L", "8"}};


        Graph g = new Graph();
        for(String[] edge : edges) {
            g.addEdge(edge[0], edge[1], Integer.parseInt(edge[2]));
        }

        // test twice to ensure reset done correctly:
        // find all paths using weighted edges
        performUnconnectedTest(g, 1);
        performUnconnectedTest(g, 2);
    }


    private static void performUnconnectedTest(Graph g, int testNum) {
    	System.out.println("PERFORMING UNCONNECTED GRAPH TEST NUMBER " + testNum);

        g.findAllPaths(true);
        int actualDiameter = g.getDiameter();
        if(actualDiameter == 6)
            System.out.println("Passed diameter test with weighted == true.");
        else
            System.out.println("Failed diameter test with weighted == true. Expected 5 got " + actualDiameter);

        double costOfLongestShortestPath = g.costOfLongestShortestPath();
        if(costOfLongestShortestPath == 16.0)
            System.out.println("Passed cost of longest shortest path test with weighted = true");
        else
            System.out.println("Failed cost of longest shortest path test with weighted = true. Expected 17.0 got " + actualDiameter);


        String[] expectedPaths
                      = {"Name: A                    cost per path: 10.0000, num paths: 6",
                         "Name: D                    cost per path: 9.6000, num paths: 5",
                         "Name: F                    cost per path: 3.0000, num paths: 4",
                         "Name: E                    cost per path: 4.2500, num paths: 4",
                         "Name: G                    cost per path: 4.2500, num paths: 4",
                         "Name: C                    cost per path: 5.7500, num paths: 4",
                         "Name: B                    cost per path: 7.5000, num paths: 4",
                         "Name: H                    cost per path: 10.2500, num paths: 4",
                         "Name: I                    cost per path: 4.3333, num paths: 3",
                         "Name: J                    cost per path: 8.0000, num paths: 1"};

        testAllPathsInfo(g, expectedPaths);
    }

    private static void testAllPathsInfo(Graph g, String[] expectedPaths) {
        int index = 0;

        for(AllPathsInfo api : g.getAllPaths()) {
            if(expectedPaths[index].equals(api.toString())) {
                System.out.println(expectedPaths[index] + " is correct!!");
            }
            else {
                System.out.println("ERROR IN ALL PATHS INFO: ");
                System.out.println("index: " + index);
                System.out.println("EXPECTED: " + expectedPaths[index]);
                System.out.println("ACTUAL: " + api.toString());
                System.out.println();
            }
            index++;
        }
        System.out.println();
    }
}